"""Crusoe extensions to the tinker request types."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import ConfigDict, Field, field_validator, model_validator
from tinker import types
from tinker._models import BaseModel, StrictBase
from tinker.types.create_session_request import CreateSessionRequest as _CreateSessionRequest
from tinker.types.load_weights_response import LoadWeightsResponse

__all__ = [
    "Checkpoint",
    "CheckpointsListResponse",
    "TrainingRun",
    "TrainingRunsResponse",
    "SliceType",
    "BaseModelConfig",
    "TrainingBaseModelConfig",
    "SamplingBaseModelConfig",
    "ServiceConfig",
    "CreateSessionRequest",
    "CloseSessionResponse",
    "LoadWeightsResponse",
    "ReadinessResponse",
    "SessionStatus",
    "SessionSummaryEntry",
    "SessionSummaryResponse",
]

SessionStatus = Literal["active", "terminated"]


class SliceType(StrEnum):
    """Known accelerator slice types — convenience constants, not a closed set.

    `slice_type` is a plain string on the wire so the service can add
    hardware without an SDK release."""

    NVIDIA_H200_141GB = "NVIDIA_H200_141GB"


class BaseModelConfig(StrictBase):
    """The fields both halves share; construct a Training/SamplingBaseModelConfig instead."""

    base_model: str
    """Base model name (e.g., "Qwen/Qwen3.5-9B")"""

    slice_type: str | None = None
    """Accelerator slice type to place the model on (e.g.
    SliceType.NVIDIA_H200_141GB); service-chosen when omitted"""

    num_replicas: int | None = Field(default=None, ge=1)
    """Number of replicas to run, each a whole node; service-chosen when
    omitted. On a sampling row a replica is serving capacity; on the
    training row it scales the trainer's data parallelism instead, so a
    seeded run will not reproduce one trained at a different value."""


class TrainingBaseModelConfig(BaseModelConfig):
    """Placement of one training base model."""


class SamplingBaseModelConfig(BaseModelConfig):
    """Placement of one sampling base model, plus its reproducible-sampling opt-in."""

    enable_seed: bool = False
    """Serve this model with deterministic inference, the only mode under which
    `SamplingParams.seed` is honoured. Off by default; sampling with a seed without it is a 400."""


class ServiceConfig(StrictBase):
    """Session-level service configuration, sent to the server at session creation.

    Describes either the placement of a new session or the id of one to reattach
    to, never both: a running session keeps the configuration it was created with.
    """

    training_client_base_models: list[TrainingBaseModelConfig] = Field(default_factory=list)
    """Base model for the session's training client"""

    sampling_client_base_models: list[SamplingBaseModelConfig] = Field(default_factory=list)
    """Base models for the session's sampling clients"""

    context_len: int | None = Field(default=None, ge=1)
    """Maximum context length in tokens (e.g., 131072 for 128k)"""

    existing_session_id: str | None = None
    """Reattach to this session instead of creating one. Cannot be combined with the placement
    fields above, and the server refuses a session that is closed or is another org or project's."""

    @model_validator(mode="after")
    def _reattach_carries_no_placement(self) -> ServiceConfig:
        """Reject a reattach id sent with placement, rather than let the server drop it.

        Every other field counts as placement, so one added later cannot silently
        become droppable alongside a reattach id.
        """
        if self.existing_session_id is None:
            return self
        conflicting = [
            name for name in type(self).model_fields if name != "existing_session_id" and getattr(self, name)
        ]
        if conflicting:
            raise ValueError(
                f"existing_session_id cannot be combined with {', '.join(conflicting)}: "
                "a running session keeps the configuration it was created with"
            )
        return self


class CreateSessionRequest(_CreateSessionRequest):
    """tinker's CreateSessionRequest plus the Crusoe service config."""

    service_config: ServiceConfig | None = None
    """Session-level model placement"""


class CloseSessionResponse(BaseModel):
    """Crusoe extension: response of POST /v1/mill/sessions/{session_id}/close."""

    status: Literal["ok"] = "ok"


class ReadinessResponse(BaseModel):
    """Crusoe extension: response of GET /v1/mill/readiness, served by the engine head.

    Only the ready arm of the head's tri-state has a body; warming and failed are a 503 and a
    terminal 4xx. Defaulted so a head that answers `{}` still reads as ready.
    """

    status: str = "ready"


class SessionSummaryEntry(BaseModel):
    """One session in a summary page."""

    model_config = ConfigDict(frozen=True, extra="ignore", populate_by_name=True)

    session_id: str

    status: str = Field(validation_alias="state")
    """Lower-cased lifecycle of the session: "active" or "terminated" today, and a new
    value if the service gains one"""

    created_at: str | None = None
    """ISO 8601 creation timestamp"""

    @field_validator("status", mode="after")
    @classmethod
    def _as_status_word(cls, status: str) -> str:
        return status.lower()


class SessionSummaryResponse(BaseModel):
    """One page of sessions, newest first."""

    sessions: list[SessionSummaryEntry]
    has_more: bool

    total: int
    """Sessions matching the filter, not just the ones on this page"""


class Checkpoint(types.Checkpoint):
    """A checkpoint as the Crusoe service lists it: its path is `mill_path`.

    `tinker_path` carries the same value, for code written against tinker's `Checkpoint`."""

    mill_path: str

    @model_validator(mode="before")
    @classmethod
    def _mirror_mill_path(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        path = data.get("mill_path", data.get("tinker_path"))
        return {"mill_path": path, "tinker_path": path, **data}


class CheckpointsListResponse(types.CheckpointsListResponse):
    """tinker's `CheckpointsListResponse`, listing Crusoe `Checkpoint`s."""

    checkpoints: list[Checkpoint]


class TrainingRun(types.TrainingRun):
    """tinker's `TrainingRun`, whose last checkpoints are Crusoe `Checkpoint`s."""

    last_checkpoint: Checkpoint | None = None
    last_sampler_checkpoint: Checkpoint | None = None


class TrainingRunsResponse(types.TrainingRunsResponse):
    """tinker's `TrainingRunsResponse`, listing Crusoe `TrainingRun`s."""

    training_runs: list[TrainingRun]
