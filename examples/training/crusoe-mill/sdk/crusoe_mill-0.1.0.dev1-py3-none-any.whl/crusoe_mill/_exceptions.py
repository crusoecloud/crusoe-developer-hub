"""The exceptions a Crusoe client raises, importable from `crusoe_mill`.

Aliases of the upstream client's classes rather than subclasses, so code that catches the upstream
base class and code that catches `crusoe_mill.MillError` see exactly the same errors."""

from ._upstream import (
    APIConnectionError,
    APIError,
    APIResponseValidationError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestFailedError,
    UnprocessableEntityError,
)
from ._upstream import UpstreamError as MillError

__all__ = [
    "APIConnectionError",
    "APIError",
    "APIResponseValidationError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "InternalServerError",
    "MillError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "RequestFailedError",
    "UnprocessableEntityError",
]
