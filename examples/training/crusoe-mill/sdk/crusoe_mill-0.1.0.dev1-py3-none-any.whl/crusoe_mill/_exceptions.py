"""The exceptions a Crusoe client raises: tinker's own classes, importable from `crusoe_mill`.

Aliases rather than subclasses, so `except crusoe_mill.MillError` and `except tinker.TinkerError`
catch exactly the same errors."""

from tinker import (
    APIConnectionError,
    APIError,
    APIResponseValidationError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestFailedError,
    UnprocessableEntityError,
)
from tinker import TinkerError as MillError

__all__ = [
    "APIConnectionError",
    "APIError",
    "APIResponseValidationError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "InternalServerError",
    "MillError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "RequestFailedError",
    "UnprocessableEntityError",
]
