"""Per-request adaptation to the Crusoe service.

Crusoe API keys have no mandated prefix, so this replaces the upstream
provider (which requires a fixed key prefix) with one that accepts any
key; the server validates keys. The key is sent as `Authorization:
Bearer <key>` — the Crusoe platform convention — not upstream's X-API-Key.
The flow also routes each request to the Crusoe service's mount: upstream's
generated client hardcodes `/api/v1/...` paths, and the Crusoe service
serves the same operations under `/v1/mill/...`.
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator

import httpx

from ._upstream import ApiKeyAuthProvider, UpstreamError
from ._upstream import auth_token_provider_module as _auth_token_provider
from ._upstream import client_module as _upstream_client
from ._upstream import internal_client_holder_module as _internal_client_holder

__all__ = ["CrusoeApiKeyAuthProvider", "install"]

UPSTREAM_PATH_PREFIX = "/api/v1/"
CRUSOE_PATH_PREFIX = "/v1/mill/"


def _reroute(url: httpx.URL) -> httpx.URL:
    """Move an upstream wire path under the Crusoe mount (/api/v1/... ->
    /v1/mill/...); URLs already outside the upstream prefix pass through."""
    if UPSTREAM_PATH_PREFIX in url.path:
        return url.copy_with(path=url.path.replace(UPSTREAM_PATH_PREFIX, CRUSOE_PATH_PREFIX, 1))
    return url


class CrusoeApiKeyAuthProvider(ApiKeyAuthProvider):
    """Resolves the API key from the arg or CRUSOE_API_KEY, sends it as
    `Authorization: Bearer <key>`, and reroutes upstream's /api/v1/ wire
    paths to the Crusoe service's /v1/mill/ mount."""

    def __init__(self, api_key: str | None = None) -> None:
        resolved = api_key or os.environ.get("CRUSOE_API_KEY")
        if not resolved:
            raise UpstreamError(
                "The api_key client option must be set either by passing api_key to the client"
                " or by setting the CRUSOE_API_KEY environment variable"
            )
        self._token = resolved

    async def async_auth_flow(self, request: httpx.Request) -> AsyncGenerator[httpx.Request, httpx.Response]:
        request.url = _reroute(request.url)
        token = await self.get_token()
        if token:
            request.headers["Authorization"] = f"Bearer {token}"
        yield request


def install() -> None:
    """Replace the upstream ApiKeyAuthProvider references with the Crusoe provider.

    Idempotent; runs at crusoe_mill import time.
    """
    _auth_token_provider.ApiKeyAuthProvider = CrusoeApiKeyAuthProvider
    _internal_client_holder.ApiKeyAuthProvider = CrusoeApiKeyAuthProvider
    _upstream_client.ApiKeyAuthProvider = CrusoeApiKeyAuthProvider
