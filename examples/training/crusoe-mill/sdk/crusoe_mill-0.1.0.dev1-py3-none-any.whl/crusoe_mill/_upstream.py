"""The one module that names the upstream client library crusoe_mill is built on.

Everything else imports from here, under names of our own. What upstream's code reaches by name
(its package, its path scheme, the checkpoint-path field, the method names its own clients call)
is spelled here and nowhere else.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import tinker._client as client_module
import tinker.lib._auth_token_provider as auth_token_provider_module
import tinker.lib.internal_client_holder as internal_client_holder_module
from tinker import (
    APIConnectionError,
    APIError,
    APIResponseValidationError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestFailedError,
    UnprocessableEntityError,
    types,
)
from tinker import TinkerError as UpstreamError
from tinker._base_client import AsyncHttpxClientWrapper
from tinker._client import AsyncTinker as AsyncUpstreamClient
from tinker._compat import model_copy
from tinker._models import BaseModel, StrictBase
from tinker._version import __version__ as upstream_version
from tinker.lib._auth_token_provider import ApiKeyAuthProvider, AuthTokenProvider
from tinker.lib.api_future_impl import QueueState, QueueStateObserver
from tinker.lib.api_future_impl import _APIFuture as APIFutureImpl
from tinker.lib.client_connection_pool_type import ClientConnectionPoolType
from tinker.lib.internal_client_holder import InternalClientHolder
from tinker.lib.public_interfaces.api_future import APIFuture, AwaitableConcurrentFuture
from tinker.lib.public_interfaces.rest_client import RestClient as UpstreamRestClient
from tinker.lib.public_interfaces.service_client import ServiceClient as UpstreamServiceClient
from tinker.lib.sync_only import sync_only
from tinker.lib.telemetry import capture_exceptions
from tinker.types.create_session_request import CreateSessionRequest as UpstreamCreateSessionRequest
from tinker.types.load_weights_response import LoadWeightsResponse

if TYPE_CHECKING:
    from tinker.lib.public_interfaces.sampling_client import SamplingClient
    from tinker.lib.public_interfaces.training_client import TrainingClient
    from tinker.lib.retry_handler import RetryConfig

PACKAGE = "tinker"
"""Upstream's distribution and import name."""

PATH_SCHEME = PACKAGE + "://"
"""Upstream's checkpoint-path scheme; its parser accepts no other."""

PATH_FIELD = "tinker_path"
"""Upstream's name for a checkpoint path, as a field and inside its method names."""

ENV_PREFIX = PACKAGE.upper() + "_"
"""Upstream reads its configuration from variables with this prefix; crusoe_mill reads none of them."""

LOGGER_NAME = PACKAGE
"""Upstream's root logger."""

POLL_LOGGER_NAME = PACKAGE + ".lib.api_future_impl"
"""The upstream logger in the poll loop, holding the per-poll "because of try_again" WARNING."""

TELEMETRY_LOGGER_NAME = PACKAGE + ".lib.telemetry"
"""The upstream logger that reports exceptions it captures."""

# Imported on first use, as upstream itself does, to break an import cycle inside upstream.
_LAZY = {
    "SamplingClient": "tinker.lib.public_interfaces.sampling_client",
    "TrainingClient": "tinker.lib.public_interfaces.training_client",
    "RetryConfig": "tinker.lib.retry_handler",
}


def __getattr__(name: str) -> Any:
    if name not in _LAZY:
        raise AttributeError(name)
    import importlib

    return getattr(importlib.import_module(_LAZY[name]), name)


def upstream_name(mill_name: str) -> str:
    """The name upstream gives a `mill_path` method or field."""
    return mill_name.replace("mill_path", PATH_FIELD)


def answer_to_upstream_names(cls: type, mill_names: tuple[str, ...]) -> None:
    """Make each `mill_path` method also answer to upstream's name, which upstream's own code calls."""
    for name in mill_names:
        setattr(cls, upstream_name(name), getattr(cls, name))


__all__ = [
    "APIConnectionError",
    "APIError",
    "APIFuture",
    "APIFutureImpl",
    "APIResponseValidationError",
    "APIStatusError",
    "APITimeoutError",
    "ApiKeyAuthProvider",
    "AsyncHttpxClientWrapper",
    "AsyncUpstreamClient",
    "AuthTokenProvider",
    "AuthenticationError",
    "AwaitableConcurrentFuture",
    "BadRequestError",
    "BaseModel",
    "ClientConnectionPoolType",
    "ConflictError",
    "ENV_PREFIX",
    "InternalClientHolder",
    "InternalServerError",
    "LOGGER_NAME",
    "LoadWeightsResponse",
    "NotFoundError",
    "PACKAGE",
    "PATH_FIELD",
    "PATH_SCHEME",
    "POLL_LOGGER_NAME",
    "PermissionDeniedError",
    "QueueState",
    "QueueStateObserver",
    "RateLimitError",
    "RequestFailedError",
    "RetryConfig",
    "SamplingClient",
    "StrictBase",
    "TELEMETRY_LOGGER_NAME",
    "TrainingClient",
    "UnprocessableEntityError",
    "UpstreamCreateSessionRequest",
    "UpstreamError",
    "UpstreamRestClient",
    "UpstreamServiceClient",
    "answer_to_upstream_names",
    "auth_token_provider_module",
    "capture_exceptions",
    "client_module",
    "internal_client_holder_module",
    "model_copy",
    "sync_only",
    "types",
    "upstream_name",
    "upstream_version",
]
