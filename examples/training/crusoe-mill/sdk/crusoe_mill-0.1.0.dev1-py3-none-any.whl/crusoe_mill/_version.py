"""Installed version of this package, resolved once from the `crusoe-mill`
distribution (the `[project] name` in pyproject.toml)."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _dist_version

try:
    __version__ = _dist_version("crusoe-mill")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"

__all__ = ["__version__"]
