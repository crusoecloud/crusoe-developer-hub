"""crusoe-mill — Crusoe fine-tuning SDK, built on tinker.

Exports what Crusoe changes: the ServiceClient and its session-level service
config, the RestClient with the session calls it answers, the checkpoint types
it lists (their path is `mill_path`), and tinker's exceptions under `MillError`.
Everything else (request and response types, client classes) is used directly
from the `tinker` package.
"""

import logging as _logging_stdlib

from ._auth import install as _install_crusoe_auth
from ._exceptions import (
    APIConnectionError,
    APIError,
    APIResponseValidationError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    MillError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestFailedError,
    UnprocessableEntityError,
)
from ._logging import configure_output as _configure_log_output
from ._logging import silence_poll_retries as _silence_poll_retries
from ._types import (
    BaseModelConfig,
    Checkpoint,
    CheckpointsListResponse,
    SamplingBaseModelConfig,
    ServiceConfig,
    SessionSummaryEntry,
    SessionSummaryResponse,
    SliceType,
    TrainingBaseModelConfig,
    TrainingRun,
    TrainingRunsResponse,
)
from ._version import __version__
from .rest_client import RestClient
from .service_client import ServiceClient

_install_crusoe_auth()
_silence_poll_retries()
_configure_log_output(_logging_stdlib.getLogger())

__all__ = [
    "APIConnectionError",
    "APIError",
    "APIResponseValidationError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "BaseModelConfig",
    "Checkpoint",
    "CheckpointsListResponse",
    "ConflictError",
    "InternalServerError",
    "MillError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "RequestFailedError",
    "RestClient",
    "SamplingBaseModelConfig",
    "ServiceClient",
    "ServiceConfig",
    "SessionSummaryEntry",
    "SessionSummaryResponse",
    "SliceType",
    "TrainingBaseModelConfig",
    "TrainingRun",
    "TrainingRunsResponse",
    "UnprocessableEntityError",
    "__version__",
]
