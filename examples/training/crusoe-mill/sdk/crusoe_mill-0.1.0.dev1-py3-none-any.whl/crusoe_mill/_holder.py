"""InternalClientHolder subclass adapting tinker to the Crusoe service."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections.abc import Awaitable, Callable, Iterator
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass
from typing import Any, TypeVar

from tinker import types
from tinker._client import AsyncTinker
from tinker._compat import model_copy
from tinker._exceptions import APIStatusError
from tinker._version import __version__ as tinker_sdk_version
from tinker.lib._auth_token_provider import AuthTokenProvider
from tinker.lib.client_connection_pool_type import ClientConnectionPoolType
from tinker.lib.internal_client_holder import InternalClientHolder

from ._progress import MAX_SINGLE_WAIT_SEC, ProvisioningProgress, report_session_note, stage_token
from ._types import CloseSessionResponse, CreateSessionRequest, ServiceConfig
from ._version import __version__ as crusoe_sdk_version

logger = logging.getLogger(__name__)

T = TypeVar("T")

SESSION_ID_HEADER = "X-Session-Id"

# Upstream's own guard on `model_path`, reproduced because our create builds the request itself.
MILL_PATH_SCHEME = "mill://"
UPSTREAM_PATH_SCHEME = "tinker://"
CHECKPOINT_PATH_SCHEMES = (MILL_PATH_SCHEME, UPSTREAM_PATH_SCHEME)

# What the constructor waits on: the engine head's own answer, proxied by the gateway. Until it
# is 200 the session's samplers cannot serve, and the head is the only component that knows.
READINESS_PATH = "/v1/mill/readiness"

_CLOSE_TIMEOUT_SEC = 10

# How often the readiness poll asks again when `Retry-After` did not survive the hops between
# the head and us (Cloudflare, the gateway, the engine-proxy). Measured on hardware: a stripped
# header dropped the wait onto the generic retryable branch, which is capped at five minutes,
# and raised the head's warming 503 at 246s against samplers that needed 460s.
_READINESS_RETRY_AFTER_FALLBACK_SEC = 10.0

# Upstream beats every 10s. One beat per session is cheap, but 10s buys nothing against a
# lease measured in minutes, so we pace it down. Module-level (upstream keeps it as a local
# inside the method) so tests can drive the loop without waiting a real minute.
_HEARTBEAT_PERIOD_SEC = 60
# A client-side log warning only — it issues no request and the server never learns of it.
# Must stay well below the server's lease so the customer is warned before being reclaimed.
_HEARTBEAT_WARNING_AFTER_SEC = 2 * 60
_HEARTBEAT_TIMEOUT_SEC = 10


@dataclass(frozen=True)
class _ProvisioningWait:
    """A 503 the server asked us to wait out, and the stage it named."""

    retry_after_seconds: float
    stage: str | None


def _provisioning_wait(e: Exception) -> _ProvisioningWait | None:
    if not isinstance(e, APIStatusError) or e.status_code != 503:
        return None
    seconds = _retry_after_seconds(e)
    if seconds is None:
        seconds = _readiness_poll_pace(e)
    if seconds is None:
        return None
    return _ProvisioningWait(
        retry_after_seconds=min(max(seconds, 1.0), MAX_SINGLE_WAIT_SEC),
        stage=_provisioning_stage(e),
    )


def _retry_after_seconds(e: APIStatusError) -> float | None:
    """The server pacing us, honoured wherever the header survives."""
    header = e.response.headers.get("retry-after")
    if header is None:
        return None
    try:
        return float(header)
    except ValueError:
        return None


def _readiness_poll_pace(e: APIStatusError) -> float | None:
    """A 503 from the readiness route is a provision still in flight by definition: that route
    refuses for no other reason. So the unbounded wait survives a hop that drops `Retry-After`.

    Scoped to that one route on purpose. Everywhere else a 503 with no header is some other
    fault, and reading it as a provision would wait out a real outage forever."""
    if not e.request.url.path.endswith(READINESS_PATH):
        return None
    return _READINESS_RETRY_AFTER_FALLBACK_SEC


def _provisioning_stage(e: APIStatusError) -> str | None:
    """A server that names no stage leaves the progress line generic."""
    if not isinstance(e.body, dict):
        return None
    return stage_token(e.body.get("stage"))


async def _post_create_session(
    holder: InternalClientHolder, request: CreateSessionRequest
) -> types.CreateSessionResponse:
    """max_retries=0 so the send policy is the caller's, not the HTTP client's budget: whether
    this POST may be sent twice depends on what it asks for. See `_send_create_session`."""
    with holder.aclient(ClientConnectionPoolType.SESSION) as client:
        return await client.service.create_session(request=request, max_retries=0)


async def _post_create_sampling_session(
    holder: InternalClientHolder, request: types.CreateSamplingSessionRequest
) -> types.CreateSamplingSessionResponse:
    """max_retries=0 for the same reason as the training submits: the POST can wait out a cold
    sampler bind, and each 503 belongs to our retry loop rather than the HTTP client's budget."""
    with holder.aclient(ClientConnectionPoolType.SESSION) as client:
        return await client.service.create_sampling_session(request=request, max_retries=0)


@contextmanager
def _session_scoped_client(
    inner: AbstractContextManager[AsyncTinker], session_id: str
) -> Iterator[AsyncTinker]:
    """Yield a copy of the pooled client whose requests carry X-Session-Id.

    with_options() shares the pooled client's connections but does not carry
    _client_config (read per request, e.g. proto_compress_fwdbwd) or
    _strict_response_validation (without it, responses degrade to loose
    construction and nested response models stay dicts), so both are passed
    through explicitly.
    """
    with inner as client:
        yield client.with_options(
            default_headers={SESSION_ID_HEADER: session_id},
            _extra_kwargs={
                "_client_config": client._client_config,
                "_strict_response_validation": client._strict_response_validation,
            },
        )


class CrusoeInternalClientHolder(InternalClientHolder):
    def __init__(
        self,
        user_metadata: dict[str, str] | None = None,
        project_id: str | None = None,
        *,
        service_config: ServiceConfig | None = None,
        **kwargs: Any,
    ) -> None:
        self._service_config = service_config
        self._session_closed = False
        # False until construction finishes: until then there is no session to wait on.
        self._owns_session = False
        # BEFORE super(), which retries the client-config fetch and so can report before the
        # session exists. One per holder and never replaced, so "one clock per session" is a
        # property of the object rather than of who asks for it first.
        self._provisioning_progress = ProvisioningProgress(self._known_session_id, time.monotonic)
        # Upstream's sampling counter has no lock, unlike its training one.
        self._sampling_session_lock = threading.Lock()
        super().__init__(user_metadata=user_metadata, project_id=project_id, **kwargs)
        self._owns_session = not kwargs.get("_skip_session", False)
        if self._telemetry is not None:
            self._telemetry.stop()
            self._telemetry = None

    def aclient(self, client_pool_type: ClientConnectionPoolType) -> AbstractContextManager[AsyncTinker]:
        """Hand out session-scoped clients: once the session id is known,
        every request carries it as X-Session-Id."""
        inner = super().aclient(client_pool_type)
        session_id = getattr(self, "_session_id", None)
        if not session_id:
            return inner
        return _session_scoped_client(inner, session_id)

    @property
    def created_its_own_session(self) -> bool:
        """False for a reattach: the session is another client's, not ours to close."""
        if self._service_config is None:
            return True
        return self._service_config.existing_session_id is None

    def next_sampling_session_seq_id(self) -> int:
        """Reserve the next sampling session's seq id, separately from the POST that uses it.

        The POST is not idempotent -- the head appends a fresh sampler row per call and
        nothing dedupes on (session_id, seq_id) -- so a retry has to reuse the id it already
        reserved rather than re-enter upstream's create and mint a row per attempt.
        """
        assert self._sampling_client_counter is not None, (
            "sampling sessions are unavailable on a session-less client (REST-only)"
        )
        with self._sampling_session_lock:
            seq_id = self._sampling_client_counter
            self._sampling_client_counter += 1
            return seq_id

    async def _create_sampling_session(
        self, model_path: str | None = None, base_model: str | None = None
    ) -> str:
        """Upstream's create, on our retry loop, so a cold sampler bind reports progress instead
        of dying at the stainless client's ten-attempt budget (~50s) with nothing logged.

        Overridden on the HOLDER rather than on `ServiceClient`, because this is the one choke
        point every entry point shares: `TrainingClient.create_sampling_client(model_path=...)`
        reaches it too, and an override above it left that path on the bare POST.

        The seq id is reserved ONCE, outside the retried call (see
        `next_sampling_session_seq_id`), so a retry cannot open a sampling session per attempt.
        """
        if model_path and not model_path.startswith(CHECKPOINT_PATH_SCHEMES):
            raise ValueError(f"model_path must start with '{MILL_PATH_SCHEME}'")
        request = types.CreateSamplingSessionRequest(
            session_id=self.get_session_id(),
            sampling_session_seq_id=self.next_sampling_session_seq_id(),
            model_path=model_path,
            base_model=base_model,
        )
        response = await self.execute_with_retries(_post_create_sampling_session, self, request)
        return response.sampling_session_id

    def close_session(self) -> None:
        if self._session_closed:
            return
        self._assert_not_on_event_loop("close the session")
        self.run_coroutine_threadsafe(self._post_close_session()).result(timeout=_CLOSE_TIMEOUT_SEC * 2)
        self._session_closed = True

    async def _post_close_session(self) -> CloseSessionResponse:
        """Close via the pooled client so the request rides the same flow —
        auth, version header, X-Session-Id — as every other API call."""
        with self.aclient(ClientConnectionPoolType.SESSION) as client:
            return await client.post(
                f"/v1/mill/sessions/{self.get_session_id()}/close",
                cast_to=CloseSessionResponse,
                options={"timeout": _CLOSE_TIMEOUT_SEC, "max_retries": 0},
            )

    async def _session_heartbeat(self, session_id: str) -> None:
        """Upstream's beat, paced to `_HEARTBEAT_PERIOD_SEC`.

        Overriding this one coroutine is enough: upstream starts the task from two
        branches depending on which thread the caller is on, and both reach
        `self._session_heartbeat`. Reproduced rather than delegated because upstream
        hardcodes the period as a local variable, so there is nothing to parameterise.

        Failures are swallowed deliberately, as upstream does: a missed beat is not the
        client's problem to solve, and raising here would kill the loop and take the
        session with it. The warning below is the only signal.
        """
        last_ok = time.monotonic()
        while True:
            await asyncio.sleep(_HEARTBEAT_PERIOD_SEC)
            last_exception: str | None = None
            try:
                with self.aclient(ClientConnectionPoolType.SESSION) as client:
                    await client.service.session_heartbeat(
                        session_id=session_id, max_retries=0, timeout=_HEARTBEAT_TIMEOUT_SEC
                    )
                last_ok = time.monotonic()
            except Exception as e:  # noqa: BLE001 — see docstring
                last_exception = f"{type(e).__name__}: {e}"
            stalled_for = time.monotonic() - last_ok
            if stalled_for > _HEARTBEAT_WARNING_AFTER_SEC:
                logger.warning(
                    "Session heartbeat has been failing for %.0fs for session %s. "
                    "Last exception: %s. Your connection may be unreliable or the service "
                    "may be down; if this persists the session will be reclaimed.",
                    stalled_for,
                    session_id,
                    last_exception,
                )

    def _known_session_id(self) -> str | None:
        """None inside our own constructor, which retries the client-config fetch before any
        session exists. Read per report rather than captured, so one early retry cannot leave
        the whole session's progress lines without the id and the `^C` hint."""
        return getattr(self, "_session_id", None)

    def provisioning_progress(self) -> ProvisioningProgress:
        """The session's ONE clock, shared by every provisioning wait it has.

        A reporter per call made 300 concurrent waits 300 clocks and 300 identical lines; a
        reporter per PHASE did the same over time, restarting the elapsed count at 0s when the
        blocking constructor handed the same wait on to `create_lora_training_client`."""
        return self._provisioning_progress

    async def execute_with_retries(
        self,
        func: Callable[..., Awaitable[T]],
        *args: Any,
        **kwargs: Any,
    ) -> T:
        """Every provisioning wait reports on the session's one clock (`provisioning_progress`)."""
        RETRY_MAX_WAIT_TIME = 60 * 5
        start_time = time.monotonic()
        attempt_count = 0
        while True:
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                if isinstance(e, APIStatusError) and self._should_pause_on_billing(e.status_code, e.message):
                    await asyncio.sleep(5)
                    continue
                # Only a client with a session can be waiting for one to be provisioned.
                wait = _provisioning_wait(e) if self._owns_session else None
                if wait is not None:
                    self.provisioning_progress().report(wait.stage)
                    await asyncio.sleep(wait.retry_after_seconds)
                    start_time = time.monotonic()
                    attempt_count = 0
                    continue
                if self._is_retryable_exception(e) and time.monotonic() - start_time < RETRY_MAX_WAIT_TIME:
                    # This branch can back off for the whole five minutes, and a bare 502 or a
                    # transport error names no stage; unreported, that is silence.
                    self.provisioning_progress().report(None)
                    time_to_wait = min(2**attempt_count, 30)
                    attempt_count += 1
                    time_to_wait = min(time_to_wait, start_time + RETRY_MAX_WAIT_TIME - time.monotonic())
                    await asyncio.sleep(time_to_wait)
                    continue
                raise e

    async def _fetch_client_config(self, auth: AuthTokenProvider) -> types.ClientConfigResponse:
        """Fetch the client config with JWT auth forced off; Crusoe uses API-key auth only.

        Reproduces upstream's one-off pool (internal_client_holder.py:548) instead of
        delegating to it, because upstream never closes that pool and has no close path
        for one. Its httpx client is then finalised by the cyclic GC, which frees the fd
        and only afterwards defers the real close onto the loop, where it unregisters an
        fd that now belongs to someone else (cpython#130141 -- open, and its only PR was
        closed unmerged, so no interpreter is going to fix it). Closing here, on the loop,
        keeps the fd ours until it is gone: measured 0 hits in 320 runs, against 39/40
        with neither fix.
        """
        pool = self._create_client_connection_pool(
            max_requests_per_client=1,
            auth=auth,
            client_config=types.ClientConfigResponse(use_pyqwest_transport=False),
        )
        # Every client this fetch touches, keyed by identity: the one handed out, and
        # whatever is in the pool afterwards. Both are needed -- on a Cloudflare 400 with
        # an empty body, and Crusoe is behind Cloudflare, `aclient()` *replaces*
        # `_clients[idx]` (internal_client_holder.py:79-86), so the client that did the
        # request is no longer in the list and is exactly the one that would leak.
        created: dict[int, AsyncTinker] = {}

        async def _once() -> types.ClientConfigResponse:
            try:
                with pool.aclient() as client:
                    created[id(client)] = client
                    return await client.service.client_config(
                        request=types.ClientConfigRequest(sdk_version=tinker_sdk_version)
                    )
            finally:
                for client in pool._clients:
                    created[id(client)] = client

        try:
            config = await self.execute_with_retries(_once)
        finally:
            # Every client, even if one raises: a sequential loop stopped at the first
            # failure and left the rest open, which is the leak this method exists to
            # prevent. Not swallowed either -- but re-raised AFTER the finally, so a
            # failed fetch keeps its own exception instead of losing it to a close error.
            closed = await asyncio.gather(
                *(client.close() for client in created.values()), return_exceptions=True
            )
        for outcome in closed:
            if isinstance(outcome, BaseException):
                raise outcome
        return model_copy(config, update={"pjwt_auth_enabled": False})

    async def _fetch_initial_client_dynamic_config(self) -> types.ClientDynamicConfigResponse:
        """The Crusoe service has no dynamic config endpoint; use defaults."""
        return types.ClientDynamicConfigResponse()

    async def _client_dynamic_config_refresh_loop(self) -> None:
        """The Crusoe service has no dynamic config endpoint; never poll."""
        return

    async def _create_session(
        self,
        user_metadata: dict[str, str] | None = None,
        project_id: str | None = None,
    ) -> str:
        request = CreateSessionRequest(
            tags=[],
            user_metadata=user_metadata or {},
            sdk_version=crusoe_sdk_version,
            project_id=project_id,
            service_config=self._service_config,
        )
        result = await self._send_create_session(request)
        if result.info_message:
            report_session_note(result.info_message)
        if result.warning_message:
            logger.warning(result.warning_message)
        if result.error_message:
            logger.error(result.error_message)
        return result.session_id

    async def _send_create_session(self, request: CreateSessionRequest) -> types.CreateSessionResponse:
        """Retried for a reattach, sent once for a create.

        The SDK intermittently fails this call with a ConnectTimeout raised before the request
        reaches the wire, and `max_retries=0` leaves nothing to absorb it. Only a reattach is
        safe to send again: the server writes no row for one, it renews the lease the heartbeat
        renews anyway. A create allocates a gang, and no transport we run on distinguishes a
        POST that never left from one whose answer was lost -- pyqwest, which production picks,
        reports both as a read timeout. So a create that may have landed is never re-sent.
        """
        if self.created_its_own_session:
            return await _post_create_session(self, request)
        return await self.execute_with_retries(_post_create_session, self, request)
