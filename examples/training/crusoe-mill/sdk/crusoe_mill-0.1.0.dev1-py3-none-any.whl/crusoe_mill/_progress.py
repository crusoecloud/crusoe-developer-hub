"""The stage vocabulary the service speaks, and one line an interval while a caller waits."""

from __future__ import annotations

import logging
from collections.abc import Callable

from ._upstream import QueueState, QueueStateObserver

logger = logging.getLogger(__name__)

# A cold start runs minutes per stage: alive enough to see, rare enough not to be noise.
PROGRESS_INTERVAL_SEC = 60

# The longest a single provisioning retry sleeps, and so the longest gap between two reports of
# ONE wait: the retry loop reports on every attempt, so a quieter gap than this means that wait
# ended. Read by `_holder` as its own clamp on a server's `Retry-After`.
MAX_SINGLE_WAIT_SEC = 5 * 60

# One phrase for the whole wait: which phase it is in names our internals, so it goes to DEBUG.
_PROVISIONING_PHRASE = "provisioning"


def stage_token(reason: str | None) -> str | None:
    """Read the token out of a `"<token>"` or `"<token>: <detail>"` wire value."""
    if not reason:
        return None
    return reason.split(":", 1)[0].strip()


def report_session_note(message: str) -> None:
    """On the progress logger because it is what puts the session id on screen."""
    logger.info(message)


class ProvisioningProgress:
    """At most one line an interval while the service provisions, whatever stage it reports.

    ONE of these per session, held by the holder: the constructor's readiness poll, the model
    build and a sampler bind are phases of one wait, and a reporter per phase restarted the
    elapsed count at 0s in the middle of it."""

    def __init__(self, session_id: Callable[[], str | None], clock: Callable[[], float]) -> None:
        # Read at report time: a reporter can be created from inside the holder's own
        # constructor, where the session it will name does not exist yet.
        self._session_id = session_id
        self._clock = clock
        self._started_at = clock()
        self._seen_at = self._started_at
        self._reported_at: float | None = None
        self._reported_stage: str | None = None

    def report(self, stage: str | None) -> None:
        now = self._clock()
        self._note_stage(stage)
        self._restart_if_the_last_wait_ended(now)
        self._seen_at = now
        if self._is_throttled(now):
            return
        self._reported_at = now
        logger.info(
            "%s — %.0fs elapsed%s",
            _PROVISIONING_PHRASE,
            now - self._started_at,
            self._release_note(),
        )

    def _restart_if_the_last_wait_ended(self, now: float) -> None:
        """A wait in flight reports at least every `MAX_SINGLE_WAIT_SEC`, so a longer gap is a
        wait that finished. The clock then counts THIS wait, not the ready session before it."""
        if now - self._seen_at <= MAX_SINGLE_WAIT_SEC:
            return
        self._started_at = now
        self._reported_at = None

    def _note_stage(self, stage: str | None) -> None:
        """Which phase a customer waited in, for support, without it reaching their terminal."""
        if stage == self._reported_stage:
            return
        self._reported_stage = stage
        logger.debug("provisioning stage: %s", stage or "unnamed")

    def _is_throttled(self, now: float) -> bool:
        """Every line now reads the same, so time is the only thing left worth pacing."""
        return self._reported_at is not None and now - self._reported_at < PROGRESS_INTERVAL_SEC

    def _release_note(self) -> str:
        """Omitted before the session exists: there is nothing yet to release."""
        session_id = self._session_id()
        if session_id is None:
            return ""
        return f" (session {session_id}; ^C releases it)"


class StageObserver(QueueStateObserver):
    """Upstream's renderer drops an active queue state and otherwise says "is paused", which
    is wrong for a model that is merely loading."""

    def __init__(self, progress: ProvisioningProgress) -> None:
        self._progress = progress

    def on_queue_state_change(self, queue_state: QueueState, queue_state_reason: str | None) -> None:
        # Every poll of a live run notifies with an active state and no stage.
        stage = stage_token(queue_state_reason)
        if stage is None:
            return
        self._progress.report(stage)
