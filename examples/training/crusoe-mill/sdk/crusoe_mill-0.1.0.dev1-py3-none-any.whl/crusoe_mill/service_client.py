"""Crusoe ServiceClient."""

from __future__ import annotations

import logging
import os
import threading
import time
from concurrent.futures import Future as ConcurrentFuture
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, cast

from tinker import types
from tinker._exceptions import APIConnectionError, APIStatusError
from tinker.lib.api_future_impl import _APIFuture
from tinker.lib.client_connection_pool_type import ClientConnectionPoolType
from tinker.lib.internal_client_holder import InternalClientHolder
from tinker.lib.public_interfaces.api_future import AwaitableConcurrentFuture
from tinker.lib.public_interfaces.service_client import ServiceClient as _ServiceClient
from tinker.lib.sync_only import sync_only
from tinker.lib.telemetry import capture_exceptions

from ._holder import CHECKPOINT_PATH_SCHEMES, MILL_PATH_SCHEME, READINESS_PATH, CrusoeInternalClientHolder
from ._progress import StageObserver
from ._types import LoadWeightsResponse, ReadinessResponse, ServiceConfig
from ._version import __version__
from .rest_client import RestClient

if TYPE_CHECKING:
    from tinker.lib.public_interfaces.sampling_client import SamplingClient
    from tinker.lib.public_interfaces.training_client import TrainingClient
    from tinker.lib.retry_handler import RetryConfig

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://intelligence.crusoecloud.com"

_CREATE_MODEL_REQUEST_TYPE = "CreateModel"
_LOAD_WEIGHTS_REQUEST_TYPE = "LoadWeights"

_SESSION_GONE_STATUS = 404
_CLIENT_ERROR_STATUSES = range(400, 500)

# The body every Crusoe component answers an error with (tinker_server.errors.error_response).
# What is in front of them -- Cloudflare, the engine-proxy's nginx, the auth backend -- answers
# HTML or nothing, so these keys are how a 4xx ABOUT this allocation is told from one that
# merely passed through something on the way.
_ERROR_CONTRACT_KEYS = ("error", "category")

# The two 404 bodies a Crusoe deployment with no readiness route answers with, and nothing else.
# `detail` is FastAPI's unmatched-route shape, which the gateway keeps for its tinker mount; the
# marker is the tinker error contract's, which the engine head answers with
# (tinker_server.errors.ROUTE_ABSENT_MARKER, held to this copy by tests/test_wire_parity.py).
_ROUTE_ABSENT_MARKER = "is not a route this deployment serves"
_UNMATCHED_ROUTE_DETAIL = HTTPStatus.NOT_FOUND.phrase

# Logged once per client, by the one shared wait, when a deployment cannot answer READINESS_PATH.
_NO_READINESS_ROUTE = (
    "this deployment does not serve %s, so construction cannot confirm the allocation is "
    "serving; continuing without the wait. Your first real call waits for the samplers instead."
)


def _leaves_the_session_usable(error: BaseException) -> bool:
    """A TimeoutError is a caller peeking at a wait still in flight, and a 4xx is the
    request's own fault -- an out-of-range rank, say -- which a retry can fix without paying
    for another provision. Everything else ended the wait with the session unusable.

    The TRAINING paths' policy only. The readiness wait inverts the 4xx arm; see
    `_readiness_leaves_the_session_usable`."""
    if isinstance(error, TimeoutError):
        return True
    if not isinstance(error, APIStatusError):
        return False
    if error.status_code == _SESSION_GONE_STATUS:
        return False
    return error.status_code in _CLIENT_ERROR_STATUSES


def _spoke_our_error_contract(error: APIStatusError) -> bool:
    """Whether the body is one of our components' own, rather than an intermediary's."""
    body = error.body
    return isinstance(body, dict) and all(key in body for key in _ERROR_CONTRACT_KEYS)


def _readiness_leaves_the_session_usable(error: BaseException) -> bool:
    """The readiness wait's OWN policy, and the INVERSE of `_leaves_the_session_usable` on the
    4xx one of our own components authored.

    There a 4xx is the request's own fault on a session that is still healthy. Here the only
    thing asked is whether the allocation can serve, and the head's terminal warm failure IS a
    400 -- same status code, opposite meaning -- so OUR 4xx says this allocation never will.

    A 4xx from a hop in front of the head says nothing about the allocation, and destroying a
    healthy one on it is the worse trade: the close rides a different route from the one that
    failed, so it succeeds in exactly the cases where it is wrong."""
    if isinstance(error, TimeoutError):
        return True
    if isinstance(error, APIConnectionError):
        # No answer at all is not a verdict either. Upstream turns Cloudflare's empty-body 400
        # into one of these to reset the connection, so this arm is that case as it arrives.
        return True
    if not isinstance(error, APIStatusError):
        # A ^C, or a build that failed: the caller is gone and nobody is left to close.
        return False
    if error.status_code not in _CLIENT_ERROR_STATUSES:
        # A 5xx that outlived the retry budget; an unroutable allocation answers one.
        return False
    return not _spoke_our_error_contract(error)


def _cannot_report_readiness(error: BaseException) -> bool:
    """True only for a 404 one of OUR routers authored for a path it does not serve: a
    deployment predating the readiness route, not a session that is gone.

    Positive, never "a 404 that is not the other thing". A 404 nobody here wrote -- nginx HTML,
    an empty body -- would otherwise read as "route absent" and turn the blocking constructor
    into a fleet-wide no-op behind one WARNING. Reading it the other way is just as costly: it
    closes the session an upgraded SDK just created, on every construction, against a fleet
    that has not rolled out yet."""
    if not isinstance(error, APIStatusError) or error.status_code != _SESSION_GONE_STATUS:
        return False
    if not isinstance(error.body, dict):
        return False
    if error.body.get("detail") == _UNMATCHED_ROUTE_DETAIL:
        return True
    return _ROUTE_ABSENT_MARKER in str(error.body.get("error", ""))


def _finished_with_a_failure(future: ConcurrentFuture[Any]) -> bool:
    """Settled and raised. A future still in flight is neither, and a cancelled one is the
    client being torn down rather than an answer to re-ask for."""
    if not future.done() or future.cancelled():
        return False
    return future.exception() is not None


def _release(holder: CrusoeInternalClientHolder) -> None:
    """Close the session, best-effort: the caller's own exception is the one worth raising.

    BaseException, so a second ^C during the close cannot replace it, and WARNING rather than
    DEBUG, because a release that failed is a gang held to its lease with nobody left holding a
    handle to it."""
    try:
        holder.close_session()
    except BaseException:  # noqa: BLE001 - see docstring
        logger.warning("releasing session %s failed", holder.get_session_id(), exc_info=True)


class _SessionReleasingFuture(AwaitableConcurrentFuture["TrainingClient"]):
    """Releases the session when the caller gives up on the wait or provisioning fails. On the
    calling thread: a KeyboardInterrupt out of .result() never reaches the holder's loop."""

    def __init__(self, future: ConcurrentFuture[TrainingClient], holder: CrusoeInternalClientHolder) -> None:
        super().__init__(future)
        self._holder = holder

    def result(self, timeout: float | None = None) -> TrainingClient:
        try:
            return super().result(timeout)
        except BaseException as error:
            if not _leaves_the_session_usable(error):
                self._abandon()
            raise

    async def result_async(self, timeout: float | None = None) -> TrainingClient:
        try:
            return await super().result_async(timeout)
        except BaseException as error:
            if not _leaves_the_session_usable(error):
                self._abandon()
            raise

    def _abandon(self) -> None:
        """Best-effort: the caller's own exception is the one worth raising."""
        if not self._releases_the_session():
            return
        self._future.cancel()
        _release(self._holder)

    def _releases_the_session(self) -> bool:
        """Never a borrowed session, nor one whose client is built: an interrupt racing a
        completed future would kill a live trainer."""
        if not self._holder.created_its_own_session:
            return False
        return not self._completed_successfully()

    def _completed_successfully(self) -> bool:
        if not self._future.done() or self._future.cancelled():
            return False
        return self._future.exception() is None


async def _get_readiness(holder: InternalClientHolder) -> ReadinessResponse:
    """max_retries=0 for the same reason as the submits below: each provisioning 503 belongs to
    our own retry loop, which reports progress and honours Retry-After, rather than to the HTTP
    client's ten-attempt budget."""
    with holder.aclient(ClientConnectionPoolType.SESSION) as client:
        return await client.get(READINESS_PATH, cast_to=ReadinessResponse, options={"max_retries": 0})


async def _post_create_model(
    holder: InternalClientHolder, request: types.CreateModelRequest
) -> types.UntypedAPIFuture:
    """max_retries=0 so a provisioning 503 reaches our own retry loop instead of being absorbed
    by the stainless client's ten-attempt budget (~50s, then a bare 503 at the caller)."""
    with holder.aclient(ClientConnectionPoolType.TRAIN) as client:
        return await client.models.create(request=request, max_retries=0)


async def _post_load_weights(
    holder: InternalClientHolder, request: types.LoadWeightsRequest
) -> types.UntypedAPIFuture:
    """max_retries=0 for the same reason as the create POST: a resume waits out the same
    provisioning, and each 503 belongs to our retry loop."""
    with holder.aclient(ClientConnectionPoolType.TRAIN) as client:
        return await client.weights.load(request=request, max_retries=0)


def _put_on_our_renderer(training_client: TrainingClient, observer: StageObserver) -> None:
    """Read at every submit, so one assignment moves the whole training surface."""
    training_client._queue_state_logger = observer


def _normalize_base_url(base_url: str) -> str:
    """The SDK sends request paths under /v1/mill/ itself, so the base URL
    must stop at the service host."""
    stripped = base_url.rstrip("/")
    for suffix in ("/v1/mill", "/api/v1"):
        if stripped.endswith(suffix):
            stripped = stripped[: -len(suffix)]
    return stripped


def resolve_base_url(base_url: str | None = None) -> str:
    """The endpoint a client with these options would use: the argument, then
    CRUSOE_BASE_URL, then the default."""
    return _normalize_base_url(base_url or os.environ.get("CRUSOE_BASE_URL") or DEFAULT_BASE_URL)


class ServiceClient(_ServiceClient):
    """The main entry point for the Crusoe fine-tuning API.

    Declaring a `service_config` provisions the session: construction creates it, starts its
    cluster and BLOCKS until the allocation can serve, reporting progress once a minute. So a
    constructor that returns is a client whose first real call will not wait, and `^C` during
    the wait releases the gang instead of leaving it on its lease. Named with no
    `service_config` it stays lazy and creates nothing, which is what makes
    `ServiceClient().create_rest_client()` a free way to list or close other sessions.

    Args:
        service_config: Session-level model placement, sent to the server at
            session creation.
        user_metadata: Optional metadata attached to the created session.
        project_id: Optional project ID for the created session.
        wait_for_ready: Provision during construction. False keeps the client lazy, and
            `wait_until_ready()` then provisions on demand. A deployment that does not serve
            the readiness route at all is logged and skipped rather than waited on, so this
            stays safe to leave on against a fleet mid-rollout.
        **kwargs: advanced options passed to the underlying HTTP client.

    The endpoint resolves from the `base_url` kwarg, then `CRUSOE_BASE_URL`,
    then the default `https://intelligence.crusoecloud.com`. The API
    key resolves from the `api_key` kwarg, then `CRUSOE_API_KEY`, and is
    required.

    Example:
    ```python
    # Returns once the session's trainer and samplers are serving.
    client = ServiceClient(
        service_config=ServiceConfig(
            training_client_base_models=[
                # Placement is optional — the service picks defaults for
                # omitted fields. A session holds ONE trainer; num_replicas
                # here widens its data parallelism rather than adding one.
                TrainingBaseModelConfig(
                    base_model="Qwen/Qwen3.5-9B",
                    slice_type=SliceType.NVIDIA_H200_141GB,
                ),
            ],
            sampling_client_base_models=[
                # Two whole nodes of serving capacity behind one sampling client.
                SamplingBaseModelConfig(base_model="Qwen/Qwen3.5-9B", num_replicas=2),
                # enable_seed serves the model deterministically; off by default.
                SamplingBaseModelConfig(base_model="Qwen/Qwen3-8B", enable_seed=True),
            ],
            # One session-level budget for trainer and samplers alike, so the
            # tightest row sets it — here the trainer's 32k, not the
            # sampler's 128k.
            context_len=32768,
        ),
    )
    training_client = client.create_lora_training_client(base_model="Qwen/Qwen3.5-9B")
    sampling_client = client.create_sampling_client(base_model="Qwen/Qwen3.5-9B")
    ```

    To pick up a session another client left running, name it *instead of* declaring
    placement; the two cannot be combined, and the server refuses a session that is
    closed or is another org or project's:

    ```python
    client = ServiceClient(service_config=ServiceConfig(existing_session_id="msess_..."))
    ```
    """

    def __init__(
        self,
        service_config: ServiceConfig | None = None,
        user_metadata: dict[str, str] | None = None,
        project_id: str | None = None,
        wait_for_ready: bool = True,
        **kwargs: Any,
    ):
        self._service_config = service_config
        # One readiness wait per client, whatever the timeout: see `_readiness_wait`.
        self._readiness_poll: AwaitableConcurrentFuture[ReadinessResponse] | None = None
        self._readiness_wait_lock = threading.Lock()
        kwargs["base_url"] = resolve_base_url(kwargs.get("base_url"))
        if kwargs.get("api_key") is None:
            kwargs["api_key"] = os.environ.get("CRUSOE_API_KEY")
            if kwargs["api_key"] is None:
                raise ValueError("api_key is required: pass api_key=... or set CRUSOE_API_KEY")
        super().__init__(user_metadata=user_metadata, project_id=project_id, **kwargs)
        headers = self._holder_kwargs.setdefault("default_headers", {})
        headers.pop("X-API-Key", None)
        headers["X-Crusoe-Mill-Version"] = __version__
        if service_config is not None and wait_for_ready:
            # LAST in __init__, after the two header edits above: the holder is built from
            # `_holder_kwargs`, so provisioning any earlier would use a stale header set.
            self._provision()

    def _provision(self) -> None:
        """Create the session, which starts the cluster, then block until it can serve.

        The wait lives here rather than in the holder's constructor because there
        `_session_holder` is still None, so `close()` short-circuits to a no-op and a failed
        provision would release nothing.
        """
        try:
            # Inside the try: this is the call that creates the session, so a ^C from here on
            # has a gang to release.
            self._get_session_holder()
            self.wait_until_ready()
        except BaseException as error:
            # BaseException, not Exception: a ^C has to release the gang now rather than pay
            # out the 15-minute lease on a session the caller has already walked away from.
            self._release_after_failed_provision(error)
            raise

    def _release_after_failed_provision(self, error: BaseException) -> None:
        """Release the gang a constructor that never returned would otherwise hold, since the
        name is never bound and the caller has no handle to close with.

        Its policy is the readiness wait's, NOT the training paths': see
        `_readiness_leaves_the_session_usable` for why the same 400 means the opposite here."""
        if _readiness_leaves_the_session_usable(error):
            # A peek at a wait still in flight is what the next caller joins; leave it running.
            return
        # Before the release and whatever it finds: nobody can reach this client to stop the
        # poll, and `close_session` is not guaranteed to succeed.
        self._cancel_readiness_wait()
        holder = cast("CrusoeInternalClientHolder | None", self._session_holder)
        if holder is None:
            # Interrupted inside the holder's constructor, which creates the session on the
            # server before it returns one: only the server's lease can close that one.
            return
        if not holder.created_its_own_session:
            return
        _release(holder)

    def _submit_readiness_wait(self) -> AwaitableConcurrentFuture[ReadinessResponse]:
        """The readiness poll on our own retry loop, so it waits out the 503s the gateway sends
        while the job queues and the head sends while its samplers warm. A 404 is terminal
        there, which is what stops a wait on a session that is gone."""
        holder = cast(CrusoeInternalClientHolder, self.holder)

        @capture_exceptions(fatal=True)
        async def _wait_for_ready_async() -> ReadinessResponse:
            _ = self  # capture_exceptions reads the telemetry provider out of this closure
            try:
                return await holder.execute_with_retries(_get_readiness, holder)
            except APIStatusError as error:
                if not _cannot_report_readiness(error):
                    raise
                logger.warning(_NO_READINESS_ROUTE, READINESS_PATH)
                return ReadinessResponse()

        return holder.run_coroutine_threadsafe(_wait_for_ready_async())

    def _readiness_wait(self) -> AwaitableConcurrentFuture[ReadinessResponse]:
        """ONE wait IN FLIGHT per client, joined by every caller and every later call.

        A submit per call left each timed-out caller's poll loop running on a clock of its own:
        four `wait_until_ready(timeout=...)` calls against a 503ing service measured four live
        loops and four duplicate progress lines, which is the pathology one progress reporter
        per session exists to prevent.

        A wait that FAILED is re-driven instead of joined. `Future.result()` replays a stored
        exception forever, so memoizing one wedged the client on the first bad answer: the
        second `wait_until_ready()` re-raised the identical object, made no second request, and
        never noticed the service had become ready."""
        with self._readiness_wait_lock:
            if self._readiness_poll is None or _finished_with_a_failure(self._readiness_poll._future):
                self._readiness_poll = self._submit_readiness_wait()
            return self._readiness_poll

    def _cancel_readiness_wait(self) -> None:
        """Stop the shared poll. `holder.close()` cancels its heartbeat and dynamic-config
        tasks, not this one, so without it a client that has been closed keeps GETting
        readiness: measured 3 more polls in the 3.5s after `close()`.

        The cancelled future is kept rather than cleared, so a call after this raises instead of
        starting a fresh poll against a session that is being torn down."""
        with self._readiness_wait_lock:
            wait = self._readiness_poll
        if wait is None:
            return
        wait._future.cancel()

    @sync_only
    def wait_until_ready(self, timeout: float | None = None) -> None:
        """Block until this client's session can serve, reporting progress once a minute.

        Called for you at construction unless you pass `wait_for_ready=False`. Unbounded by
        default: a contended plan can queue for as long as the fleet takes, and giving up here
        would release a gang the caller is still waiting on. There is one wait IN FLIGHT per
        client: a `timeout` that expires leaves that wait running, and every later call joins it
        and its progress clock rather than starting a second poll loop. A wait that FAILED is
        re-driven by the next call instead, so a bad answer does not wedge the client.

        Args:
        - `timeout`: Seconds to wait before raising `TimeoutError`; None waits indefinitely
        """
        self._readiness_wait().result(timeout)

    async def wait_until_ready_async(self, timeout: float | None = None) -> None:
        """Async version of wait_until_ready."""
        await self._readiness_wait().result_async(timeout)

    def _create_lora_training_client_submit(
        self,
        base_model: str,
        rank: int,
        seed: int | None,
        train_mlp: bool,
        train_attn: bool,
        train_unembed: bool,
        user_metadata: dict[str, str] | None,
    ) -> AwaitableConcurrentFuture[TrainingClient]:
        """Upstream's submit, with the create_model POST run through execute_with_retries:
        posted bare it would fail at the HTTP client's budget. The parameters are upstream's."""
        assert any([train_mlp, train_attn, train_unembed]), (
            "At least one of train_mlp, train_attn, or train_unembed must be True"
        )
        # Lazy holder creation must not run on the event loop, and the seq id needs the lock.
        holder = cast(CrusoeInternalClientHolder, self.holder)
        session_id = holder.get_session_id()
        model_seq_id = holder.get_training_client_id()
        request = types.CreateModelRequest(
            session_id=session_id,
            model_seq_id=model_seq_id,
            base_model=base_model,
            lora_config=types.LoraConfig(
                rank=rank,
                seed=seed,
                train_mlp=train_mlp,
                train_attn=train_attn,
                train_unembed=train_unembed,
            ),
            user_metadata=user_metadata,
        )
        # The session's clock, so the POST's 503s, the future's stage polls and the wait the
        # constructor already reported on are one count rather than three that each start at 0s.
        observer = StageObserver(holder.provisioning_progress())

        @capture_exceptions(fatal=True)
        async def _create_lora_training_client_async() -> TrainingClient:
            _ = self  # capture_exceptions reads the telemetry provider out of this closure
            start_time = time.time()
            future = await holder.execute_with_retries(_post_create_model, holder, request)
            response = await _APIFuture(
                types.CreateModelResponse,
                holder,
                future,
                request_start_time=start_time,
                request_type=_CREATE_MODEL_REQUEST_TYPE,
                queue_state_observer=observer,
            ).result_async()
            # Imported here, as upstream does, to break an import cycle.
            from tinker.lib.public_interfaces.training_client import TrainingClient

            training_client = TrainingClient(holder, model_seq_id=model_seq_id, model_id=response.model_id)
            _put_on_our_renderer(training_client, observer)
            logger.debug("training client ready for model %s", response.model_id)
            return training_client

        submitted = holder.run_coroutine_threadsafe(_create_lora_training_client_async())
        return _SessionReleasingFuture(submitted.future(), holder)

    def _create_training_client_via_load_weights_submit(
        self,
        path: str,
        optimizer: bool,
        base_model: str | None,
        user_metadata: dict[str, str] | None,
        weights_access_token: str | None,
    ) -> AwaitableConcurrentFuture[TrainingClient]:
        """The create path's treatment for a resume, which waits out the same provisioning.
        The parameters are upstream's; the entry points that choose this path read
        `holder._client_config` first, so the session exists before the POST either way."""
        holder = cast(CrusoeInternalClientHolder, self.holder)
        session_id = holder.get_session_id()
        model_seq_id = holder.get_training_client_id()
        # What the server derives from the same pair, so the response is not needed for it.
        model_id = f"{session_id}:train:{model_seq_id}"
        request = types.LoadWeightsRequest(
            session_id=session_id,
            model_seq_id=model_seq_id,
            base_model=base_model,
            user_metadata=user_metadata,
            path=path,
            optimizer=optimizer,
            weights_access_token=weights_access_token,
        )
        # The session's clock, for the same reason as the create path above.
        observer = StageObserver(holder.provisioning_progress())

        @capture_exceptions(fatal=True)
        async def _create_via_load_weights_async() -> TrainingClient:
            _ = self  # capture_exceptions reads the telemetry provider out of this closure
            start_time = time.time()
            future = await holder.execute_with_retries(_post_load_weights, holder, request)
            await _APIFuture(
                LoadWeightsResponse,
                holder,
                future,
                request_start_time=start_time,
                request_type=_LOAD_WEIGHTS_REQUEST_TYPE,
                queue_state_observer=observer,
            ).result_async()
            # Imported here, as upstream does, to break an import cycle.
            from tinker.lib.public_interfaces.training_client import TrainingClient

            training_client = TrainingClient(holder, model_seq_id=model_seq_id, model_id=model_id)
            _put_on_our_renderer(training_client, observer)
            logger.debug("training client ready for model %s, via load_weights", model_id)
            return training_client

        submitted = holder.run_coroutine_threadsafe(_create_via_load_weights_async())
        return _SessionReleasingFuture(submitted.future(), holder)

    def _create_sampling_client_submit(
        self, model_path: str | None, base_model: str | None
    ) -> AwaitableConcurrentFuture[str]:
        """Upstream's submit over the holder's `_create_sampling_session`, which is where the
        retry loop and the once-reserved seq id now live -- so the entry points upstream owns,
        `TrainingClient.create_sampling_client(model_path=...)` above all, are covered by the
        same code rather than by a second copy of it.

        Both refusals are upstream's, hoisted ABOVE `self.holder`: reaching the holder to refuse
        a typo creates a session, and so a gang."""
        if model_path is None and base_model is None:
            raise ValueError("Either model_path or base_model must be provided")
        if model_path and not model_path.startswith(CHECKPOINT_PATH_SCHEMES):
            raise ValueError(f"model_path must start with '{MILL_PATH_SCHEME}'")
        # Lazy holder creation must not run on the event loop.
        holder = cast(CrusoeInternalClientHolder, self.holder)

        @capture_exceptions(fatal=True)
        async def _create_sampling_session_async() -> str:
            _ = self  # capture_exceptions reads the telemetry provider out of this closure
            return await holder._create_sampling_session(model_path=model_path, base_model=base_model)

        return holder.run_coroutine_threadsafe(_create_sampling_session_async())

    def create_sampling_client(
        self,
        model_path: str | None = None,
        base_model: str | None = None,
        retry_config: RetryConfig | None = None,
    ) -> SamplingClient:
        """Upstream's call, with the sampling-session POST on our retry loop. Not wrapped in a
        `_SessionReleasingFuture` like the training submits: by the time this is reachable the
        session is already serving, so a sampling client that fails is not a failed provision.
        The parameters are upstream's."""
        # Imported here, as upstream does, to break an import cycle.
        from tinker.lib.public_interfaces.sampling_client import SamplingClient

        sampling_session_id = self._create_sampling_client_submit(model_path, base_model).result()
        # Handed the id, `create` only constructs -- the POST above was the whole round trip.
        return SamplingClient.create(
            self.holder, sampling_session_id=sampling_session_id, retry_config=retry_config
        ).result()

    async def create_sampling_client_async(
        self,
        model_path: str | None = None,
        base_model: str | None = None,
        retry_config: RetryConfig | None = None,
    ) -> SamplingClient:
        """Async version of create_sampling_client."""
        # Imported here, as upstream does, to break an import cycle.
        from tinker.lib.public_interfaces.sampling_client import SamplingClient

        sampling_session_id = await self._create_sampling_client_submit(model_path, base_model)
        return await SamplingClient.create(
            self.holder, sampling_session_id=sampling_session_id, retry_config=retry_config
        )

    def _get_session_holder(self) -> InternalClientHolder:
        if self._session_holder is not None:
            return self._session_holder
        with self._session_holder_lock:
            if self._session_holder is None:
                self._session_holder = CrusoeInternalClientHolder(
                    user_metadata=self._user_metadata,
                    project_id=self._project_id,
                    service_config=self._service_config,
                    **self._holder_kwargs,
                )
                logger.info(f"ServiceClient initialized for session {self._session_holder._session_id}")
            return self._session_holder

    def _get_rest_holder(self) -> InternalClientHolder:
        if self._rest_holder is not None:
            return self._rest_holder
        with self._rest_holder_lock:
            if self._rest_holder is None:
                self._rest_holder = CrusoeInternalClientHolder(_skip_session=True, **self._holder_kwargs)
            return self._rest_holder

    def create_rest_client(self) -> RestClient:
        """Create a RestClient, which adds the Crusoe session calls and `whoami` to tinker's.

        It creates no session of its own, so building one only to list or close costs nothing.
        """
        return RestClient(self._get_rest_holder())

    @property
    def session_id(self) -> str:
        """The session this client holds, created on first use like any other access."""
        return self.holder.get_session_id()

    def close(self) -> None:
        """Close the session, releasing its trainer and samplers immediately.

        Idempotent; raises on failure so the caller can retry. Sessions that
        are never closed are reclaimed by the server once their heartbeats
        stop (e.g. when the process exits).
        """
        # First, so a `close_session` that raises still leaves no poll behind to retry against.
        self._cancel_readiness_wait()
        holder = self._session_holder
        if holder is None:
            return
        holder.close_session()
        holder.close()
