"""The `crusoe-mill` command-line interface."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import click
from tinker import APIStatusError, TinkerError

from ._types import CloseSessionResponse, SessionSummaryResponse
from ._version import __version__
from .rest_client import DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, RestClient
from .service_client import ServiceClient, resolve_base_url

__all__ = ["main", "open_rest_client"]

EMPTY = "-"

VERBOSE_LOGGERS = ("crusoe_mill", "tinker")

REST_CLIENT_FACTORY = "crusoe_mill.rest_client_factory"
"""`ctx.meta` key holding the callable that opens the REST client."""


def open_rest_client() -> RestClient:
    """A REST client for the endpoint and API key in the environment."""
    return ServiceClient().create_rest_client()


def _echo_endpoint() -> None:
    """Say which endpoint the command is about to use, before it calls it."""
    click.echo(f"Using {resolve_base_url()}", err=True)


def _configure_logging(verbose: bool) -> None:
    """Show the SDK's own progress and retry logs."""
    if not verbose:
        return
    logging.basicConfig(format="%(levelname)s %(name)s: %(message)s")
    for name in VERBOSE_LOGGERS:
        logging.getLogger(name).setLevel(logging.INFO)


@dataclass(frozen=True)
class CliContext:
    """What every command needs: how to print, and how to reach the service."""

    output_format: str
    open_rest_client: Callable[[], RestClient]


def _service_message(error: APIStatusError) -> str:
    """The service's own description of the failure, where it sends one."""
    body = error.body
    if isinstance(body, dict) and isinstance(body.get("error"), str):
        return body["error"]
    return error.message


@contextmanager
def _reported_as_cli_error() -> Iterator[None]:
    """Report a failed call as one error line instead of a traceback."""
    try:
        yield
    except APIStatusError as e:
        raise click.ClickException(f"{e.status_code}: {_service_message(e)}") from e
    except (TinkerError, ValueError) as e:
        raise click.ClickException(str(e)) from e


def _print_json(payload: dict[str, Any]) -> None:
    click.echo(json.dumps(payload, indent=2, default=str))


def _local_time(created_at: str | None) -> str:
    """The service's ISO timestamp as local wall time; unparseable values pass through."""
    if not created_at:
        return EMPTY
    try:
        return datetime.fromisoformat(created_at).astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return created_at


def _print_session_table(page: SessionSummaryResponse) -> None:
    from rich.console import Console
    from rich.table import Table

    table = Table(title=f"Sessions ({len(page.sessions)} of {page.total})")
    table.add_column("Session ID", style="bright_cyan", no_wrap=True)
    for column in ("Status", "Created"):
        table.add_column(column)
    for summary in page.sessions:
        table.add_row(summary.session_id, summary.status, _local_time(summary.created_at))
    Console(emoji=False).print(table)


def _print_session_page(page: SessionSummaryResponse, output_format: str) -> None:
    """Render one page to stdout; anything about the page itself goes to stderr."""
    if output_format == "json":
        _print_json(page.model_dump(mode="json", exclude_none=True))
    else:
        _print_session_table(page)
    if page.has_more and page.sessions:
        click.echo(f"More sessions: --after {page.sessions[-1].session_id}", err=True)


def _print_closed(session_id: str, response: CloseSessionResponse, output_format: str) -> None:
    if output_format == "json":
        _print_json({"session_id": session_id, **response.model_dump(mode="json")})
        return
    click.echo(f"Closed {session_id}")


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.option("-v", "--verbose", is_flag=True, help="Log the SDK's retries and progress.")
@click.version_option(__version__, "-V", "--version")
@click.pass_context
def main(ctx: click.Context, output_format: str, verbose: bool) -> None:
    """Manage Crusoe fine-tuning sessions.

    Reads CRUSOE_API_KEY, and CRUSOE_BASE_URL for a non-default endpoint.
    """
    _configure_logging(verbose)
    ctx.obj = CliContext(output_format, ctx.meta.get(REST_CLIENT_FACTORY, open_rest_client))


@main.group()
def session() -> None:
    """List and close sessions."""


@session.command("list")
@click.option("--status", type=click.Choice(["active", "terminated"]), help="Only sessions in this state.")
@click.option(
    "--limit",
    type=click.IntRange(1, MAX_PAGE_SIZE),
    default=DEFAULT_PAGE_SIZE,
    show_default=True,
    help="Sessions per page.",
)
@click.option("--after", metavar="SESSION_ID", help="Continue after this session id.")
@click.pass_obj
def list_sessions(context: CliContext, status: str | None, limit: int, after: str | None) -> None:
    """List this API key's project's sessions, newest first.

    \b
        crusoe-mill session list --status active
        crusoe-mill --format json session list --limit 100
    """
    _echo_endpoint()
    with _reported_as_cli_error():
        page = context.open_rest_client().get_sessions_summary(limit, after=after, status=status).result()
    _print_session_page(page, context.output_format)


@session.command("close")
@click.argument("session_id")
@click.pass_obj
def close_session(context: CliContext, session_id: str) -> None:
    """Close SESSION_ID, releasing its trainer and samplers immediately.

    Closing an already-closed session succeeds, so this is safe to repeat.
    """
    _echo_endpoint()
    with _reported_as_cli_error():
        response = context.open_rest_client().close_session(session_id).result()
    _print_closed(session_id, response, context.output_format)


if __name__ == "__main__":
    main()
