"""Logging setup at import: crusoe_tinker is the product entry point, not a buried library,
so it takes a position on what its customers see."""

from __future__ import annotations

import logging
import os

# The one logger in the poll loop, holding the per-poll "because of try_again" WARNING.
POLL_LOGGER_NAME = "tinker.lib.api_future_impl"

OUR_LOGGER_NAME = "crusoe_tinker"

KEEP_POLL_LOGS_ENV_VAR = "CRUSOE_TINKER_LOG_POLLS"
SKIP_OUTPUT_SETUP_ENV_VAR = "CRUSOE_TINKER_SKIP_LOG_SETUP"

_HANDLER_NAME = "crusoe_tinker"
_LOG_FORMAT = "[%(asctime)s %(name)s %(levelname)s] %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_DISABLED_VALUES = frozenset({"", "0", "false", "no"})


def _opted_in(env_var: str) -> bool:
    return os.environ.get(env_var, "").strip().lower() not in _DISABLED_VALUES


def silence_poll_retries() -> None:
    """A future polls every 20s and WARNs each time; a step-0 eval runs hundreds at once."""
    if _opted_in(KEEP_POLL_LOGS_ENV_VAR):
        return
    logging.getLogger(POLL_LOGGER_NAME).setLevel(logging.ERROR)


def configure_output(root_logger: logging.Logger) -> None:
    """Give our progress lines a level, and a destination when nothing else has claimed one."""
    if _opted_in(SKIP_OUTPUT_SETUP_ENV_VAR):
        return
    _show_our_own_records()
    # A customer who already owns the root output keeps it; propagation reaches it.
    if root_logger.handlers:
        return
    _attach_handler()


def _show_our_own_records() -> None:
    """INFO, unless the customer set a level on us themselves."""
    our_logger = logging.getLogger(OUR_LOGGER_NAME)
    if our_logger.level == logging.NOTSET:
        our_logger.setLevel(logging.INFO)


def _attach_handler() -> None:
    """Scoped to our logger plus the silenced `tinker` one, whose surviving ERRORs need a home."""
    handler = logging.StreamHandler()
    handler.set_name(_HANDLER_NAME)
    handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT))
    for name in (OUR_LOGGER_NAME, POLL_LOGGER_NAME):
        logger = logging.getLogger(name)
        if any(existing.get_name() == _HANDLER_NAME for existing in logger.handlers):
            continue
        logger.addHandler(handler)
        # The usual layout imports us first and calls basicConfig inside main(), so ownership
        # is decided here, not by that ordering; propagation would print every line twice.
        logger.propagate = False
