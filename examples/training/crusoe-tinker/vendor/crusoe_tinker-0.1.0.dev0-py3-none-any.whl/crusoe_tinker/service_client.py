"""Crusoe ServiceClient."""

from __future__ import annotations

import logging
import os
import time
from concurrent.futures import Future as ConcurrentFuture
from typing import TYPE_CHECKING, Any, cast

from tinker import types
from tinker._exceptions import APIStatusError
from tinker.lib.api_future_impl import _APIFuture
from tinker.lib.client_connection_pool_type import ClientConnectionPoolType
from tinker.lib.internal_client_holder import InternalClientHolder
from tinker.lib.public_interfaces.api_future import AwaitableConcurrentFuture
from tinker.lib.public_interfaces.service_client import ServiceClient as _ServiceClient
from tinker.lib.telemetry import capture_exceptions

from ._holder import CrusoeInternalClientHolder
from ._progress import ProvisioningProgress, StageObserver
from ._types import ServiceConfig
from ._version import __version__
from .rest_client import RestClient

if TYPE_CHECKING:
    from tinker.lib.public_interfaces.training_client import TrainingClient

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://intelligence.crusoecloud.com"

_CREATE_MODEL_REQUEST_TYPE = "CreateModel"
_LOAD_WEIGHTS_REQUEST_TYPE = "LoadWeights"

_SESSION_GONE_STATUS = 404
_CLIENT_ERROR_STATUSES = range(400, 500)


def _leaves_the_session_usable(error: BaseException) -> bool:
    """A TimeoutError is a caller peeking at a wait still in flight, and a 4xx is the
    request's own fault -- an out-of-range rank, say -- which a retry can fix without paying
    for another provision. Everything else ended the wait with the session unusable."""
    if isinstance(error, TimeoutError):
        return True
    if not isinstance(error, APIStatusError):
        return False
    if error.status_code == _SESSION_GONE_STATUS:
        return False
    return error.status_code in _CLIENT_ERROR_STATUSES


class _SessionReleasingFuture(AwaitableConcurrentFuture["TrainingClient"]):
    """Releases the session when the caller gives up on the wait or provisioning fails. On the
    calling thread: a KeyboardInterrupt out of .result() never reaches the holder's loop."""

    def __init__(self, future: ConcurrentFuture[TrainingClient], holder: CrusoeInternalClientHolder) -> None:
        super().__init__(future)
        self._holder = holder

    def result(self, timeout: float | None = None) -> TrainingClient:
        try:
            return super().result(timeout)
        except BaseException as error:
            if not _leaves_the_session_usable(error):
                self._abandon()
            raise

    async def result_async(self, timeout: float | None = None) -> TrainingClient:
        try:
            return await super().result_async(timeout)
        except BaseException as error:
            if not _leaves_the_session_usable(error):
                self._abandon()
            raise

    def _abandon(self) -> None:
        """Best-effort: the caller's own exception is the one worth raising."""
        if not self._releases_the_session():
            return
        self._future.cancel()
        try:
            self._holder.close_session()
        except Exception:
            # The caller's own exception is the one worth raising, but a release that failed is
            # a held gang, so it must not be invisible.
            logger.debug("releasing session %s failed", self._holder.get_session_id(), exc_info=True)

    def _releases_the_session(self) -> bool:
        """Never a borrowed session, nor one whose client is built: an interrupt racing a
        completed future would kill a live trainer."""
        if not self._holder.created_its_own_session:
            return False
        return not self._completed_successfully()

    def _completed_successfully(self) -> bool:
        if not self._future.done() or self._future.cancelled():
            return False
        return self._future.exception() is None


async def _post_create_model(
    holder: InternalClientHolder, request: types.CreateModelRequest
) -> types.UntypedAPIFuture:
    """max_retries=0 so a provisioning 503 reaches our own retry loop instead of being absorbed
    by the stainless client's ten-attempt budget (~50s, then a bare 503 at the caller)."""
    with holder.aclient(ClientConnectionPoolType.TRAIN) as client:
        return await client.models.create(request=request, max_retries=0)


async def _post_load_weights(
    holder: InternalClientHolder, request: types.LoadWeightsRequest
) -> types.UntypedAPIFuture:
    """max_retries=0 for the same reason as the create POST: a resume waits out the same
    provisioning, and each 503 belongs to our retry loop."""
    with holder.aclient(ClientConnectionPoolType.TRAIN) as client:
        return await client.weights.load(request=request, max_retries=0)


def _put_on_our_renderer(training_client: TrainingClient, observer: StageObserver) -> None:
    """Read at every submit, so one assignment moves the whole training surface."""
    training_client._queue_state_logger = observer


def _normalize_base_url(base_url: str) -> str:
    """The SDK sends request paths under /v1/tinker/ itself, so the base URL
    must stop at the service host."""
    stripped = base_url.rstrip("/")
    for suffix in ("/v1/tinker", "/api/v1"):
        if stripped.endswith(suffix):
            stripped = stripped[: -len(suffix)]
    return stripped


def resolve_base_url(base_url: str | None = None) -> str:
    """The endpoint a client with these options would use: the argument, then
    CRUSOE_BASE_URL, then the default."""
    return _normalize_base_url(base_url or os.environ.get("CRUSOE_BASE_URL") or DEFAULT_BASE_URL)


class ServiceClient(_ServiceClient):
    """The main entry point for the Crusoe fine-tuning API.

    Args:
        service_config: Session-level model placement, sent to the server at
            session creation.
        user_metadata: Optional metadata attached to the created session.
        project_id: Optional project ID for the created session.
        **kwargs: advanced options passed to the underlying HTTP client.

    The endpoint resolves from the `base_url` kwarg, then `CRUSOE_BASE_URL`,
    then the default `https://intelligence.crusoecloud.com`. The API
    key resolves from the `api_key` kwarg, then `CRUSOE_API_KEY`, and is
    required.

    Example:
    ```python
    client = ServiceClient(
        service_config=ServiceConfig(
            training_client_base_models=[
                # Placement is optional — the service picks defaults for
                # omitted fields. A session holds ONE trainer, so
                # num_replicas belongs on a sampling row, not this one.
                TrainingBaseModelConfig(
                    base_model="Qwen/Qwen3.5-9B",
                    slice_type=SliceType.NVIDIA_H200_141GB,
                ),
            ],
            sampling_client_base_models=[
                # Two whole nodes of serving capacity behind one sampling client.
                SamplingBaseModelConfig(base_model="Qwen/Qwen3.5-9B", num_replicas=2),
                # enable_seed serves the model deterministically; off by default.
                SamplingBaseModelConfig(base_model="Qwen/Qwen3-8B", enable_seed=True),
            ],
            # One session-level budget for trainer and samplers alike, so the
            # tightest row sets it — here the trainer's 32k, not the
            # sampler's 128k.
            context_len=32768,
        ),
    )
    training_client = client.create_lora_training_client(base_model="Qwen/Qwen3.5-9B")
    sampling_client = client.create_sampling_client(base_model="Qwen/Qwen3.5-9B")
    ```

    To pick up a session another client left running, name it *instead of* declaring
    placement; the two cannot be combined, and the server refuses a session that is
    closed or is another org or project's:

    ```python
    client = ServiceClient(service_config=ServiceConfig(existing_session_id="tsess_..."))
    ```
    """

    def __init__(
        self,
        service_config: ServiceConfig | None = None,
        user_metadata: dict[str, str] | None = None,
        project_id: str | None = None,
        **kwargs: Any,
    ):
        self._service_config = service_config
        kwargs["base_url"] = resolve_base_url(kwargs.get("base_url"))
        if kwargs.get("api_key") is None:
            kwargs["api_key"] = os.environ.get("CRUSOE_API_KEY")
            if kwargs["api_key"] is None:
                raise ValueError("api_key is required: pass api_key=... or set CRUSOE_API_KEY")
        super().__init__(user_metadata=user_metadata, project_id=project_id, **kwargs)
        headers = self._holder_kwargs.setdefault("default_headers", {})
        headers.pop("X-API-Key", None)
        headers["X-Crusoe-Tinker-Version"] = __version__

    def _create_lora_training_client_submit(
        self,
        base_model: str,
        rank: int,
        seed: int | None,
        train_mlp: bool,
        train_attn: bool,
        train_unembed: bool,
        user_metadata: dict[str, str] | None,
    ) -> AwaitableConcurrentFuture[TrainingClient]:
        """Upstream's submit, with the create_model POST run through execute_with_retries:
        posted bare it would fail at the HTTP client's budget. The parameters are upstream's."""
        assert any([train_mlp, train_attn, train_unembed]), (
            "At least one of train_mlp, train_attn, or train_unembed must be True"
        )
        # Lazy holder creation must not run on the event loop, and the seq id needs the lock.
        holder = cast(CrusoeInternalClientHolder, self.holder)
        session_id = holder.get_session_id()
        model_seq_id = holder.get_training_client_id()
        request = types.CreateModelRequest(
            session_id=session_id,
            model_seq_id=model_seq_id,
            base_model=base_model,
            lora_config=types.LoraConfig(
                rank=rank,
                seed=seed,
                train_mlp=train_mlp,
                train_attn=train_attn,
                train_unembed=train_unembed,
            ),
            user_metadata=user_metadata,
        )
        # One wait, so the POST's 503s and the future's stage polls share a clock and throttle.
        progress = ProvisioningProgress(session_id)
        observer = StageObserver(progress)

        @capture_exceptions(fatal=True)
        async def _create_lora_training_client_async() -> TrainingClient:
            _ = self  # capture_exceptions reads the telemetry provider out of this closure
            start_time = time.time()
            future = await holder.execute_with_retries(_post_create_model, holder, request, progress=progress)
            response = await _APIFuture(
                types.CreateModelResponse,
                holder,
                future,
                request_start_time=start_time,
                request_type=_CREATE_MODEL_REQUEST_TYPE,
                queue_state_observer=observer,
            ).result_async()
            # Imported here, as upstream does, to break an import cycle.
            from tinker.lib.public_interfaces.training_client import TrainingClient

            training_client = TrainingClient(holder, model_seq_id=model_seq_id, model_id=response.model_id)
            _put_on_our_renderer(training_client, observer)
            logger.debug("training client ready for model %s", response.model_id)
            return training_client

        submitted = holder.run_coroutine_threadsafe(_create_lora_training_client_async())
        return _SessionReleasingFuture(submitted.future(), holder)

    def _create_training_client_via_load_weights_submit(
        self,
        path: str,
        optimizer: bool,
        base_model: str | None,
        user_metadata: dict[str, str] | None,
        weights_access_token: str | None,
    ) -> AwaitableConcurrentFuture[TrainingClient]:
        """The create path's treatment for a resume, which waits out the same provisioning.
        The parameters are upstream's; the entry points that choose this path read
        `holder._client_config` first, so the session exists before the POST either way."""
        holder = cast(CrusoeInternalClientHolder, self.holder)
        session_id = holder.get_session_id()
        model_seq_id = holder.get_training_client_id()
        # What the server derives from the same pair, so the response is not needed for it.
        model_id = f"{session_id}:train:{model_seq_id}"
        request = types.LoadWeightsRequest(
            session_id=session_id,
            model_seq_id=model_seq_id,
            base_model=base_model,
            user_metadata=user_metadata,
            path=path,
            optimizer=optimizer,
            weights_access_token=weights_access_token,
        )
        # One wait, so the POST's 503s and the future's stage polls share a clock and throttle.
        progress = ProvisioningProgress(session_id)
        observer = StageObserver(progress)

        @capture_exceptions(fatal=True)
        async def _create_via_load_weights_async() -> TrainingClient:
            _ = self  # capture_exceptions reads the telemetry provider out of this closure
            start_time = time.time()
            future = await holder.execute_with_retries(_post_load_weights, holder, request, progress=progress)
            await _APIFuture(
                types.LoadWeightsResponse,
                holder,
                future,
                request_start_time=start_time,
                request_type=_LOAD_WEIGHTS_REQUEST_TYPE,
                queue_state_observer=observer,
            ).result_async()
            # Imported here, as upstream does, to break an import cycle.
            from tinker.lib.public_interfaces.training_client import TrainingClient

            training_client = TrainingClient(holder, model_seq_id=model_seq_id, model_id=model_id)
            _put_on_our_renderer(training_client, observer)
            logger.debug("training client ready for model %s, via load_weights", model_id)
            return training_client

        submitted = holder.run_coroutine_threadsafe(_create_via_load_weights_async())
        return _SessionReleasingFuture(submitted.future(), holder)

    def _get_session_holder(self) -> InternalClientHolder:
        if self._session_holder is not None:
            return self._session_holder
        with self._session_holder_lock:
            if self._session_holder is None:
                self._session_holder = CrusoeInternalClientHolder(
                    user_metadata=self._user_metadata,
                    project_id=self._project_id,
                    service_config=self._service_config,
                    **self._holder_kwargs,
                )
                logger.info(f"ServiceClient initialized for session {self._session_holder._session_id}")
            return self._session_holder

    def _get_rest_holder(self) -> InternalClientHolder:
        if self._rest_holder is not None:
            return self._rest_holder
        with self._rest_holder_lock:
            if self._rest_holder is None:
                self._rest_holder = CrusoeInternalClientHolder(_skip_session=True, **self._holder_kwargs)
            return self._rest_holder

    def create_rest_client(self) -> RestClient:
        """Create a RestClient, which adds the Crusoe session calls and `whoami` to tinker's.

        It creates no session of its own, so building one only to list or close costs nothing.
        """
        return RestClient(self._get_rest_holder())

    @property
    def session_id(self) -> str:
        """The session this client holds, created on first use like any other access."""
        return self.holder.get_session_id()

    def close(self) -> None:
        """Close the session, releasing its trainer and samplers immediately.

        Idempotent; raises on failure so the caller can retry. Sessions that
        are never closed are reclaimed by the server once their heartbeats
        stop (e.g. when the process exits).
        """
        holder = self._session_holder
        if holder is None:
            return
        holder.close_session()
        holder.close()
