"""crusoe-tinker — Crusoe fine-tuning SDK, built on tinker.

Exports only what Crusoe changes: the ServiceClient and its session-level
service config, and the RestClient with the session calls it answers.
Everything else (types, exceptions, client classes) is used directly from
the `tinker` package.
"""

import logging as _logging_stdlib

from ._auth import install as _install_crusoe_auth
from ._logging import configure_output as _configure_log_output
from ._logging import silence_poll_retries as _silence_poll_retries
from ._types import (
    BaseModelConfig,
    SamplingBaseModelConfig,
    ServiceConfig,
    SessionSummaryEntry,
    SessionSummaryResponse,
    SliceType,
    TrainingBaseModelConfig,
)
from ._version import __version__
from .rest_client import RestClient
from .service_client import ServiceClient

_install_crusoe_auth()
_silence_poll_retries()
_configure_log_output(_logging_stdlib.getLogger())

__all__ = [
    "BaseModelConfig",
    "RestClient",
    "SamplingBaseModelConfig",
    "ServiceClient",
    "ServiceConfig",
    "SessionSummaryEntry",
    "SessionSummaryResponse",
    "SliceType",
    "TrainingBaseModelConfig",
    "__version__",
]
