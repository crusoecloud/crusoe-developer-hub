"""Crusoe RestClient."""

from __future__ import annotations

from concurrent.futures import Future as ConcurrentFuture

from tinker import types
from tinker.lib.client_connection_pool_type import ClientConnectionPoolType
from tinker.lib.public_interfaces.api_future import APIFuture, AwaitableConcurrentFuture
from tinker.lib.public_interfaces.rest_client import RestClient as _RestClient
from tinker.lib.sync_only import sync_only

from ._types import CloseSessionResponse, SessionStatus, SessionSummaryResponse

__all__ = ["RestClient", "DEFAULT_PAGE_SIZE", "MAX_PAGE_SIZE"]

SESSIONS_PATH = "/v1/tinker/sessions"

DEFAULT_PAGE_SIZE = 10
"""Sessions per page when the caller names none."""

MAX_PAGE_SIZE = 100
"""Largest page the service accepts."""


def _page_params(limit: int, after: str | None, status: SessionStatus | None) -> dict[str, object]:
    """Query params for one page; an unset cursor or filter is omitted, never sent empty."""
    params: dict[str, object] = {"limit": limit}
    if after is not None:
        params["after"] = after
    if status is not None:
        params["status"] = status
    return params


class RestClient(_RestClient):
    """tinker's RestClient plus the Crusoe session calls, and `whoami` served by the API.

    You get one from `ServiceClient.create_rest_client()`. It holds no session of
    its own, so listing and closing work from any process holding the API key.

    Example:
    ```python
    rest_client = ServiceClient().create_rest_client()
    page = rest_client.get_sessions_summary(status="active").result()
    for session in page.sessions:
        rest_client.close_session(session.session_id).result()
    ```
    """

    def _get_sessions_summary_submit(
        self, params: dict[str, object]
    ) -> AwaitableConcurrentFuture[SessionSummaryResponse]:
        async def _get_sessions_summary_async() -> SessionSummaryResponse:
            async def _send_request() -> SessionSummaryResponse:
                with self.holder.aclient(ClientConnectionPoolType.TRAIN) as client:
                    return await client.get(
                        f"{SESSIONS_PATH}/summary",
                        options={"params": params},
                        cast_to=SessionSummaryResponse,
                    )

            return await self.holder.execute_with_retries(_send_request)

        return self.holder.run_coroutine_threadsafe(_get_sessions_summary_async())

    @sync_only
    def get_sessions_summary(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        *,
        after: str | None = None,
        status: SessionStatus | None = None,
    ) -> ConcurrentFuture[SessionSummaryResponse]:
        """A page of this project's sessions, newest first, with a row per session.

        Args:
        - `limit`: Sessions per page, 1..100 (default 10)
        - `after`: Continue after this session id — the last id of the previous
          page, when that page reported `has_more`
        - `status`: Only sessions that are "active" or "terminated"

        Returns:
        - A `Future` containing one `SessionSummaryResponse` page
        """
        return self._get_sessions_summary_submit(_page_params(limit, after, status)).future()

    async def get_sessions_summary_async(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        *,
        after: str | None = None,
        status: SessionStatus | None = None,
    ) -> SessionSummaryResponse:
        """Async version of get_sessions_summary."""
        return await self._get_sessions_summary_submit(_page_params(limit, after, status))

    def _close_session_submit(self, session_id: str) -> AwaitableConcurrentFuture[CloseSessionResponse]:
        async def _close_session_async() -> CloseSessionResponse:
            async def _send_request() -> CloseSessionResponse:
                with self.holder.aclient(ClientConnectionPoolType.TRAIN) as client:
                    return await client.post(
                        f"{SESSIONS_PATH}/{session_id}/close", cast_to=CloseSessionResponse
                    )

            return await self.holder.execute_with_retries(_send_request)

        return self.holder.run_coroutine_threadsafe(_close_session_async())

    @sync_only
    def close_session(self, session_id: str) -> ConcurrentFuture[CloseSessionResponse]:
        """Close a session by id, releasing its trainer and samplers immediately.

        Unlike `ServiceClient.close()`, this closes a session the caller did not
        create — any session of the API key's org and project. Idempotent: closing
        an already-closed session succeeds.

        Args:
        - `session_id`: The session to close

        Returns:
        - A `Future` containing the `CloseSessionResponse`
        """
        return self._close_session_submit(session_id).future()

    async def close_session_async(self, session_id: str) -> CloseSessionResponse:
        """Async version of close_session."""
        return await self._close_session_submit(session_id)

    def whoami(self) -> APIFuture[types.WhoamiResponse]:
        """Get the calling principal's identity.

        Asks the server, where upstream decodes a JWT it already holds. A Crusoe API key is
        opaque — it carries no claims — so upstream's path raises `RuntimeError` here. The
        difference a caller can see is that this costs one request.
        """

        async def _whoami_async() -> types.WhoamiResponse:
            async def _send_request() -> types.WhoamiResponse:
                # Spelled as the upstream wire path, unlike the session calls above: whoami is an
                # upstream method, so `CrusoeApiKeyAuthProvider` reroutes it onto the Crusoe mount.
                with self.holder.aclient(ClientConnectionPoolType.TRAIN) as client:
                    return await client.get("/api/v1/whoami", cast_to=types.WhoamiResponse)

            return await self.holder.execute_with_retries(_send_request)

        return self.holder.run_coroutine_threadsafe(_whoami_async())
